<h2>Gaussian Naive Bayes Implementation in Python</h2>

<li> GNB is defined in gnbScratch.py </li>
<li> GNB can be trained using train_gnb.py</li>
